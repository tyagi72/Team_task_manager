Team Task Manager (Full Stack)

Features:
- Authentication (basic)
- Project management
- Task creation and tracking

Run Backend:
cd backend
npm install express cors
node server.js

Run Frontend:
Open index.html in browser

Tech:
- Node.js
- Express
- HTML + JS
